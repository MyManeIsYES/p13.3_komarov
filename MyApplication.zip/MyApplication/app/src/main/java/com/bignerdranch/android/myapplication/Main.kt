package com.bignerdranch.android.myapplication

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Main : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun splashscreen(view: View){
        val intent= Intent(this,Splashscreen::class.java)
        startActivity(intent)
    }
}